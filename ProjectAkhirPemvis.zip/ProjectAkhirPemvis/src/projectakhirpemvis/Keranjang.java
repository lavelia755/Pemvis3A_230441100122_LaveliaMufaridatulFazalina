/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projectakhirpemvis;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Lavilia
 */
public class Keranjang {
    private List<Produk> daftarProduk;
    private static Keranjang instance; // Menyimpan satu-satunya instance

    // Konstruktor private agar objek tidak bisa dibuat langsung
    private Keranjang() {
        daftarProduk = new ArrayList<>();
    }

    // Metode getInstance untuk mendapatkan instance tunggal
    public static Keranjang getInstance() {
        if (instance == null) {
            synchronized (Keranjang.class) {
                if (instance == null) {
                    instance = new Keranjang();
                }
            }
        }
        return instance;
    }

    // Menambahkan produk ke daftar keranjang
    public void tambahProduk(Produk produk) {
        daftarProduk.add(produk);
    }
    
    public void kosongkanKeranjang() {
        daftarProduk.clear(); // Asumsikan daftarProduk adalah List<Produk>
    }

    // Mengambil daftar produk yang ada di keranjang
    public List<Produk> getDaftarProduk() {
        return daftarProduk;
    }
}