/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projectakhirpemvis;

/**
 *
 * @author Lavilia
 */
public class Produk {
    private int id;
    private String nama;
    private double harga;
    private String deskripsi;
    private int jumlah;

    // Konstruktor utama untuk Produk dengan semua atribut
    public Produk(int id, String nama, double harga, String deskripsi) {
        this.id = id;
        this.nama = nama;
        this.harga = harga;
        this.deskripsi = deskripsi;
        this.jumlah = jumlah;
    }

    // Konstruktor tambahan yang hanya membutuhkan nama dan harga produk
    public Produk(String namaProduk, double hargaProduk) {
        this.nama = namaProduk;
        this.harga = hargaProduk;
        this.id = 0;  // Anda bisa memberikan nilai default untuk id
        this.deskripsi = "Tidak ada deskripsi"; // Deskripsi default
    }

    // Getter dan Setter
    public int getId() {
        return id;
    }

    public String getNama() {
        return nama;
    }

    public double getHarga() {
        return harga;
    }

    public String getDeskripsi() {
        return deskripsi;
    }
    // Getter untuk jumlah produk
    public int getJumlah() {
        return jumlah;
    }

    // Setter untuk jumlah produk
    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }


    @Override
    public String toString() {
        return nama + " - " + harga;
    }
}