/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projectakhirpemvis;

import javax.swing.ListModel;

/**
 *
 * @author Lavilia
 */
public class Pesanan {
    private String email;
    private String alamat;
    private ListModel<String> detailPesanan;
    private String totalHarga;
    private String pesanKhusus;
    private String status;

    public Pesanan(String email, String alamat, ListModel<String> detailPesanan, String totalHarga, String pesanKhusus) {
        this.email = email;
        this.alamat = alamat;
        this.detailPesanan = detailPesanan;
        this.totalHarga = totalHarga;
        this.pesanKhusus = pesanKhusus;
        this.status = "Belum selesai";
    }
    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getEmail() {
        return email;
    }

    public String getAlamat() {
        return alamat;
    }

    public ListModel<String> getDetailPesanan() {
        return detailPesanan;
    }

    public String getTotalHarga() {
        return totalHarga;
    }

    public String getPesanKhusus() {
        return pesanKhusus;
    }
}