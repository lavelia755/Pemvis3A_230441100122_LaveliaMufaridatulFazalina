/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projectakhirpemvis;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Lavilia
 */
public class Main {
    public static List<Pesanan> daftarPesanan = new ArrayList<>();
    

    public static void main(String[] args) {
        // Jalankan aplikasi
        new User().setVisible(true);
    }
}